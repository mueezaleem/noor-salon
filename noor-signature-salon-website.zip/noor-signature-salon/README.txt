NOOR SIGNATURE SALON — WEBSITE

Open index.html in any modern browser.

Files:
- index.html
- style.css
- script.js

Business details used from the provided Google Maps listing:
- Name: Noor signature Salon
- Category: Beauty salon
- Address: Plot No.66, Gulshan E Bilal, University Rd, Azam Block Sargodha, 40100, Pakistan
- Phone: +92 307 4879994
- Google rating at build time: 4.2 / 5 (12 reviews)

Important:
- Current opening hours were not available from the accessible listing data, so the site asks users to confirm hours directly.
- Service cards are enquiry categories and explicitly do not claim each service is currently offered.
- Gallery/hero images are representative Unsplash editorial images loaded from remote URLs. Replace the image URLs in index.html/style.css with the salon's own photos if desired.
- All content is plain HTML/CSS/JS and fully editable.
