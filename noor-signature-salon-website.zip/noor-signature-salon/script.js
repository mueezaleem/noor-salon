const menuBtn = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');
menuBtn?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', String(open));
});
document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

document.querySelectorAll('[data-service]').forEach(card => {
  card.addEventListener('click', (e) => {
    e.preventDefault();
    const service = card.dataset.service;
    const message = `Hi Noor Signature Salon, I'd like to ask about ${service}. Please share the price and available timings.`;
    window.open(`https://wa.me/923074879994?text=${encodeURIComponent(message)}`, '_blank', 'noopener');
  });
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
document.getElementById('year').textContent = new Date().getFullYear();
